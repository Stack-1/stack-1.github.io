#include <stdio.h>

#define LEN 4

//Da implementare usando header file

int subset(int *arr,int n){
	int count = 1;
	int max_count = count;
	int i;	
	int flag = 0;

	for(i = 0;i<n-1;i++){
		if(arr[i+1]>arr[i]){
			count++;
		}else{
			if(count > max_count){
				max_count = count;
			}
			count = 1;
		}
	}
	
	if(count>max_count){
		max_count = count;
	}
	
	return max_count;
}

int main(int argc, char **argv){
	int arr[LEN] = {10,7,6,3}; 	

	printf("Il risultato e': %d\n",subset(arr,LEN));

	return 0;
}

#include <stdio.h>
#include "max.h"

//Da implementare, trovare il minimo dell'array

int main(int argc, char **argv){
	int arr[LEN] = {10,4,1,5,3};
	
	printf("Il massimo risulta: %d\n",max(arr,LEN));
	
	return 0;
}

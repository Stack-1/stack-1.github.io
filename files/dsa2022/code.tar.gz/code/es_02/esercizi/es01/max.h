#define LEN 5

int max(int *arr,int n);

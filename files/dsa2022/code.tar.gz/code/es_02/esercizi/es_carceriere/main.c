#include <stdio.h>

#define N 4
#define M 6
#define S 2

//Idea d'implementazione, utilizzare header file e trovando il test case per il quale l'algoritmo non funziona

int conta(int n,int m, int s){
	int res = (s+m-1)%n;
	return res;
}

int main(){
	
	printf("%d\n",conta(N,M,S));

	return 0;
}

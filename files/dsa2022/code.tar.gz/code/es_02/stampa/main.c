#include <stdio.h>
#include <stdlib.h>

void stampa(int *a){
	printf("\nStampa della variabile a...\nIndirizzo in esadecimale:0x%x\nIndirizzo:%lu\nValore:%d\n",(unsigned int)a,(long unsigned int)a,*a);
}

void modifica(int *a){
	(*a)++;
}

int main(int argc, char **argv){
	int a = 3;
	int *x;

	printf("Stampa della variabile a...\nIndirizzo in esadecimale:0x%x\nIndirizzo:%lu\nValore:%d\n",(unsigned int)&a,(long unsigned int)&a,a);

	stampa(&a); 
	/*Passo alla funzione l'indirizzo di memoria di a, 
	in modo da riuscire a modificare l'originale e non la copia*/	
	
	modifica(&a);
	stampa(&a); 

	x = (int *)malloc(sizeof(int));
	*x = 3;
	
	puts("\nStampa con malloc");
	printf("Stampa della variabile x...\nIndirizzo in esadecimale:0x%x\nIndirizzo:%lu\nValore:%d\n",(unsigned int)x,(long unsigned int)x,*x);
	
	free(x);	
		
	return 0;
}

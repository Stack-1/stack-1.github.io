#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int euclide(int m, int n){
	int r;
	r = m%n;
	while(r != 0){
		m = n;
		n = r;
		r = m%n;
	}
	return n;
}

int main(int argc, char **argv){
	int res;
	int m,n;
	
	if(argc != 3){
		puts("Lancaire il programma come: [./exe] [n] [m]");
		goto end;
	}			
	
	if(argv[1]>argv[2]){
		m = atoi(argv[1]);
		n = atoi(argv[2]);
	}
	else{
		m = atoi(argv[2]);
		n = atoi(argv[1]);
	}
	
	
	res = euclide(n,m); //Controllare l'input prima di passarlo alla funzione		

	printf("Il risultato e' :%d\n",res);
end:
	return 0;
}

#include <stdio.h>
#include <stdlib.h>

int gcd(int a, int b){
	int temp;
	while(b != 0){
		temp = b;
		b = a%b;
		a = temp;	
	}
	return a;
}

int lcm(int a, int b){
	int c;
	
	c = (a*b)/gcd(a,b);
	return c;
}


int main(int argc, char **argv){
	int res;
	int a,b;

	if(argc != 3){
		puts("Inserire 2 argomenti nel programma");
	}
	else{
		a = atoi(argv[1]); //Do not use atoi, it's only the fastest way to do it
		b = atoi(argv[2]);

		res = lcm(a,b);
		printf("The result is: %d\n",res);
	}
	

	return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include "mcm.h"

int gcd(int a, int b){
	int temp;
	while(b != 0){
		temp = b;
		b = a%b;
		a = temp;	
	}
	return a;
}

int lcm(int a, int b){
	int c;
	
	c = (a*b)/gcd(a,b);
	return c;
}



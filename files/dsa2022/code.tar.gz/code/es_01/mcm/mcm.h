

int gcd(int a, int b);
int lcm(int a, int b);

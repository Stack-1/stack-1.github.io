#include <stdio.h>
#include <time.h>


int fibonacci(int n){
	if(n<=2){
		return 1;
	}
	else{
		return fibonacci(n-1)+fibonacci(n-2);
	}
}


int main(){
	int n;
	unsigned int res;
    double time_spent = 0.0;
   	clock_t begin;
	clock_t end;
	
	puts("Inserire il numero di fibonacci da calcolare");
	scanf("%d",&n); //Attenzione ad usare scanf, il modo migliore sarebbe gestire l'input in una funzione separata dal main
	
	begin = clock();	    		
	
	res = fibonacci(n);
	
	end = clock();

   	// calcola il tempo trascorso trovando la differenza (end - begin) e
    // dividendo la differenza per CLOCKS_PER_SEC per convertire in secondi
    time_spent += (double)(end - begin) / CLOCKS_PER_SEC;
 
    printf("Tempo impiegato: %f secondi\n", time_spent);
		
	printf("Il risultato è: %u\n",res);
	return 0;
}


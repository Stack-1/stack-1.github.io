#include "n_pow.h"

int log_n_pow(int n, int x){
	unsigned int k;
	unsigned int p = 1;	

	while(n>0){
		k = n&1;
		if(k > 0)
			p = p*x;
		x = x*x;
		n = n>>1;
	}
	return p;
}

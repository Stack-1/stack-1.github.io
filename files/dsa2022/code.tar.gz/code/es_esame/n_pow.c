#include "n_pow.h"

int n_pow(int n,int x){
	unsigned int pow = x;
	for(int i = 1;i<n;i++){
		pow = pow * x;
	}
	return pow;
}

#include <stdio.h>
#include <stdlib.h>
#include "n_pow.h"

int main(int argc, char **argv){
	if(argc != 3){
		puts("Error: invalid number of arguments --> ./[prog] [n] [x] to calculate x^n");	
		return -1;
	}
	
	printf("Result with O(log(n)) algorithm: \t%d\n", log_n_pow(atoi(argv[1]), atoi(argv[2])) );
	printf("Result with O(N) algorithm: \t\t%d\n", n_pow(atoi(argv[1]), atoi(argv[2])) );
	return 0;
}

int n_pow(int n, int x);
int log_n_pow(int n, int x);

#include "sudoku.h"

bool colCheck(int col, int num){ 
	int temp_row;
	for (int temp_row = 0; temp_row < N; temp_row++)
      		if (mat[temp_row][col] == num)
         		return true;
	return false;
}

bool rowCheck(int row, int num){
	int temp_col;
	for (temp_col = 0; temp_col < N; temp_col++)
		if (mat[row][temp_col] == num)
        		return true;
   	return false;
}

bool checkBox(int row, int col, int num){
	int temp_row,temp_col;
	int row_offset = row - (row%3);
	int col_offset = col - (col%3);

	for (temp_row = 0; temp_row < 3; temp_row++){
      		for (temp_col = 0; temp_col < 3; temp_col++){
         		if (mat[temp_row+row_offset][temp_col+col_offset] == num)
            			return true;
		}
	}
   return false;
}

bool findBlank(int *r, int *c){
	int row, col;
   	for (row = 0; row < N; row++){
      		for (col = 0; col < N; col++){
         		if (mat[row][col] == 0)
         		{
				*r = row;
				*c = col;
	 			return true;
	 		}
		}
	}
   	return false;
}

bool checkValid(int row, int col, int num){
   return !rowCheck(row, num) && !colCheck(col, num) && !checkBox(row,col,num);
}

bool solveSudoku(){
   	int row, col;
   	int num;
	
	if (!findBlank(&row, &col)){
		return true;
	}
   	for (num = 1; num <= 9; num++){ 
      		if (checkValid(row, col, num)){ 
			mat[row][col] = num;
         		if (solveSudoku())
            			return true;
        		mat[row][col] = 0; 
		}
   	}

   	return false;
}

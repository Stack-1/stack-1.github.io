#include <stdio.h>
#include <time.h>
#include <stdbool.h>
#define N 9

int mat[N][N];/* = {
   {1, 0, 9, 5, 0, 8, 4, 0, 0},
   {5, 0, 0, 0, 0, 0, 0, 0, 0},
   {0, 8, 0, 0, 0, 0, 0, 3, 1},
   {0, 0, 3, 0, 1, 0, 8, 0, 0},
   {9, 0, 0, 8, 6, 3, 0, 0, 5},
   {0, 5, 0, 0, 9, 0, 6, 0, 0},
   {1, 3, 0, 0, 0, 0, 2, 5, 0},
   {0, 0, 0, 0, 5, 0, 0, 0, 4},
   {0, 0, 5, 2, 0, 6, 3, 0, 0}
};
*/
bool solveSudoku();
bool checkValid();
void __print_sudoku();

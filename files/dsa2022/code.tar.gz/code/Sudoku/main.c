#include "sudoku.h"
int mat[N][N] = {
   {0, 0, 6, 4, 3, 0, 0, 5, 7},
   {0, 1, 5, 0, 7, 8, 6, 3, 0},
   {0, 3, 9, 1, 0, 0, 2, 0, 0},
   {0, 4, 0, 9, 2, 0, 0, 0, 0},
   {0, 0, 0, 8, 5, 7, 0, 0, 6},
   {0, 0, 0, 0, 1, 0, 0, 0, 5},
   {3, 0, 4, 6, 8, 0, 0, 9, 0},
   {0, 2, 0, 0, 0, 1, 0, 7, 3},
   {9, 5, 0, 7, 0, 3, 8, 6, 0}
};

int main(){
	double time_spent = 0.0;
	clock_t begin,end;
	int row,col;	
	
/*	for(row = 0;row<N;row++){
		for(col = 0;col<N;col++){
			if(checkValid(row,col,mat[row][col]))
				puts("Error");
				return false;
		}
	}
*/
	begin = clock();	

   	if (solveSudoku() == true)
      		__print_sudoku();
   	else
      		puts("Non esistono soluzioni");

	end = clock();

	time_spent += (double)(end - begin) / CLOCKS_PER_SEC;

 	printf("Tempo impiegato: %f secondi\n", time_spent);
	fflush(stdout);
}

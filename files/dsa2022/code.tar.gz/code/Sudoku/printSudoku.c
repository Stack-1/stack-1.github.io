#include "sudoku.h"


int mat2[N][N] = {
   {1, 0, 9, 5, 0, 8, 4, 0, 0},
   {5, 0, 0, 0, 0, 0, 0, 0, 0},
   {0, 8, 0, 0, 0, 0, 0, 3, 1},
   {0, 0, 3, 0, 1, 0, 8, 0, 0},
   {9, 0, 0, 8, 6, 3, 0, 0, 5},
   {0, 5, 0, 0, 9, 0, 6, 0, 0},
   {1, 3, 0, 0, 0, 0, 2, 5, 0},
   {0, 0, 0, 0, 5, 0, 0, 0, 4},
   {0, 0, 5, 2, 0, 6, 3, 0, 0}
};


void __print_sudoku(){
	for (int row = 0; row < N; row++){ 
		if(row == 3 || row == 6){
			for(int i = 0;i<9;i++)
				printf("- ");   
			puts("");
		}
  		for (int col = 0; col < N; col++){
        		printf("%d ",mat[row][col]);
         			if(col == 2 || col == 5)
					printf("| ");

      		}
  		puts("");
	} 
  
}


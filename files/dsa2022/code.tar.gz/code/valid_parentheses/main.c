#include "utils.h"

int main(int argc, char **argv){
	if(argc != 2){
		puts("Invalid input");
	}else{
		if(check_string(argv[1])){
			if(isValid(argv[1]))
				puts("Valid");
			else
				puts("Not valid");
		}else{
			puts("Invalid string");
		}	
	}
	return 0;
}

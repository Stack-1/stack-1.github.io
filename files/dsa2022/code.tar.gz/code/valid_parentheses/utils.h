#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <malloc.h>

bool check_string(char *s);
bool isValid(char *s);

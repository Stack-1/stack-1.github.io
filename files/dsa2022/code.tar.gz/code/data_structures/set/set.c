#include <string.h> //Serve solo in questo file
#include "set.h"

int is_present(struct set *s,int x){
	int ret = 0;
	int i = 0;
	
	if(s->values != NULL){
		for(i=0;i<s->size;i++){
			if(s->values[i] == x){
				ret = 1;
				break;
			}
		}
	}
	
	return ret;
} 


int get_size(struct set *s){
	int size = 0;
	
	if(s != NULL)
	{
		size = s->size;
	}
	return size;
}



void set_add(struct set *s, int x){
	int *temp;	

	if(s->values == NULL){
		s->size = 1;
		s->values = (int *)malloc(sizeof(int));
		s->values[0] = x;
	}else{
		if(!is_present(s,x)){
			temp = (int *)malloc(sizeof((s->values)));
			memcpy(temp,s->values,sizeof(int)*s->size);
			s->size++;
			s->values = (int *)malloc(sizeof(int)*(s->size));
			memcpy(s->values,temp,sizeof(int)*s->size);
			s->values[s->size-1] = x;
			free(temp);
		}
	}	
		
}

void __print_set(struct set *s){
	int i = 0;
	
	for(i=0;i<s->size;i++){
		printf("%d ",s->values[i]);
	}
	puts("");
}

#include <malloc.h>
#include <stdio.h>

struct set{
	size_t size;	
	int *values;
};


int get_size(struct set *s);
void set_add(struct set *s, int x);
void __print_set(struct set *s);

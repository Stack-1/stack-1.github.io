#include "set.h"

/*
Questa struttura dati di tipo set serve solamente per mostrare come si potrebbe realizzare un'implementazione
pratica in codice C. Non rappresenta assolutamente l'implementazione migliore in codice o in velocita'.
Si utilizzano concetti base del C senza introdurre soluzioni troppo difficili da capire per un neofita.
*/


int main(int argc, char **argv){
	struct set *s1 = malloc(sizeof(struct set));
	
	set_add(s1,1);	
	__print_set(s1);

	set_add(s1,3);
	set_add(s1,3);
	__print_set(s1);	
	

	return 0;
}

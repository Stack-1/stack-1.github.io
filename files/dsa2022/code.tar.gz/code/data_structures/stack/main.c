#include "stack.h"


int main(int argc, char **argv){
	stack *s = new_stack();
	
	__print_stack(s);
	
	push(s,1);
	__print_stack(s);
	
	push(s,2);
	__print_stack(s);

	pop(s);
	__print_stack(s);

	push(s,3);
	__print_stack(s);

	return 0;
}

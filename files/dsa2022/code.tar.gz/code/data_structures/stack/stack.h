#include <malloc.h>
#include <stdio.h> //Usefull for NULL

typedef struct node{
	int value;
	struct node *next;
}node;

typedef struct stack{
	node *head;
}stack;

void push(stack *s, int x);
void pop(stack *s);
void __print_stack(stack *s);
stack *new_stack();

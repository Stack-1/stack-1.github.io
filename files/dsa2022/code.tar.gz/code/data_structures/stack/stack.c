#include "stack.h"

stack *new_stack(){
	stack *s = (stack *)malloc(sizeof(stack));
	s->head = (node *)malloc(sizeof(node));
	s->head->value = (int)NULL;
	return s;
}

void push(stack *s,int x){
	node *new = (node *)malloc(sizeof(node));
	node *curr = s->head;

	new->value = x;
	
	while(curr->next != NULL){
		curr = curr->next;
	}
	curr->next = new;
}

void pop(stack *s){
	node *curr = s->head;
	
	if(curr->next != NULL){
		while(curr->next->next != NULL){
			curr = curr->next;
		}
		curr->next = NULL;
	}
	
}

void __print_stack(stack *s){
	node *curr = s->head;

	while(curr->next != NULL){
		printf("%d ",curr->value);
	
	curr = curr->next;
	}

	printf("%d\n",curr->value);
}

#include <stdio.h>
#include <stdlib.h>

int max(int *arr,int len);

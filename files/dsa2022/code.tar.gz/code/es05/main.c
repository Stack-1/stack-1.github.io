#include "myfun.h"

int main(int argc, char **argv){
	int size = argc-1;
	int *arr;
	
	arr = (int *)malloc(sizeof(int)*size);

	
	if(arr == NULL){
		puts("Errore nella malloc");
		goto end;
	}
	

	for(int i = 0;i<size;i++){
		arr[i] = atoi(argv[i+1]);		
	}

	printf("Il massimo elemento del vettore risulta: %d\n",max(arr,size));

end:
	return 0;
}

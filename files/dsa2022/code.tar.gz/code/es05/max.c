#include "myfun.h"

int max(int *arr,int len){
	int _max = 0;
	
	for(int i = 0;i<len;i++){
		if(_max < arr[i]){
			_max = arr[i];
		}
	}

	return _max;
}

#include "myfun.h"


int main(int argc, char **argv){
	
	fun1();

	fun2();	

	return 0;
}

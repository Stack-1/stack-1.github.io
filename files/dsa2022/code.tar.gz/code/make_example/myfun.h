#include <stdio.h>

void fun1();
void fun2();

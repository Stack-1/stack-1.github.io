#include "myfun.h"


void fun1(){
	puts("This is fun 1");
}

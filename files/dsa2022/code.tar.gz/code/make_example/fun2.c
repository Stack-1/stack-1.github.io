#include "myfun.h"


void fun2(){
	puts("This is fun 2");
}
